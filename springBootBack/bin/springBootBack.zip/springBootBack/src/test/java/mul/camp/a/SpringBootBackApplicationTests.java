package mul.camp.a;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootBackApplicationTests {

	@Test
	void contextLoads() {
	}

}
