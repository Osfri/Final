package mul.camp.a.controller;

import org.springframework.web.bind.annotation.RestController;

@RestController
public class MemberController {

	
}
